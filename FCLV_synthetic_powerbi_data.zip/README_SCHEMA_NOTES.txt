FCLV Synthetic Power BI Dataset

All data is fictional and synthetic. No real Las Vegas Lights FC, customer, CRM, ticketing, or merchandise data is included.

Schema review from uploaded templates:
- Members, Matches, Attendance, and Merchandise column structures were valid.
- MembershipSales had a typo: SeastsPurchased was corrected to SeatsPurchased.
- MembershipSales also included MatchID in the uploaded file. For season-ticket membership revenue, MatchID is not needed because sales relate to members and seasons, not individual matches. Match-level activity is captured in Attendance using MemberID + MatchID.

Recommended Power BI relationships:
- Members[MemberID] 1-to-many MembershipSales[MemberID]
- Members[MemberID] 1-to-many Attendance[MemberID]
- Members[MemberID] 1-to-many Merchandise[MemberID]
- Matches[MatchID] 1-to-many Attendance[MatchID]

Table row counts:
- Members: 500
- Matches: 18
- MembershipSales: 928
- Attendance: 9000
- Merchandise: 893

Power Query practice intentionally included:
- Some inconsistent casing in FirstName, LastName, Segment, and SeatType.
- Some extra spaces in Segment values.
- Some SeatType aliases such as GA, Premium, and premium deck.

Suggested cleanup mapping:
- GA, General admission, general admission -> General Admission
- Premium, Premium deck, premium deck -> Premium Deck
- Trim and Proper Case FirstName, LastName, Segment, and SeatType
- Convert JoinDate, SaleDate, MatchDate, PurchaseDate to Date type
- Convert TotalAmount to Currency/Decimal
- Convert Attended to true/false or 1/0 for attendance rate calculations
